from blog.models import Post
from blog.serializers import PostSerializer
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser

#CRUD methods

@csrf_exempt
def post_list(request):
    if(request.method == "GET"):
        posts = Post.objects.all()
        serializer = PostSerializer(posts, many=True)
        return JsonResponse(serializer.data, safe=False)
    elif(request.method == "POST"):
        postToAdd = JSONParser().parse(request)
        serializer = PostSerializer(data=postToAdd)
        if(serializer.is_valid()):
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)

@csrf_exempt
def post_detail(request, post_id):
    try:
        post = Post.objects.get(pk=post_id)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=404)
    if(request.method == "GET"):
        serializer = PostSerializer(post)
        return JsonResponse(serializer.data)
    elif(request.method == "PUT"):
        curPost = JSONParser().parse(request)
        serializer = PostSerializer(post, curPost)
        if(serializer.is_valid()):
            serializer.save()
            return JsonResponse(serializer.data)
    elif(request.method == "DELETE"):
        post.delete()
        serializer = PostSerializer(post)
        return JsonResponse(serializer.data)

