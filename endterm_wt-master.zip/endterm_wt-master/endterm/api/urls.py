from django.contrib import admin
from django.urls import path, include
from . import views
from rest_framework import routers

urlpatterns = [
    path('post/', views.post_list),
    path('post/<int:post_id>', views.post_detail),
]